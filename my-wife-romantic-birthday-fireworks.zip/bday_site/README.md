MY WIFE — ROMANTIC BIRTHDAY SURPRISE 💗

A small, romantic birthday website made with love for 13 November.

FEATURES
- Welcome screen with a personal birthday surprise
- Live countdown to the next 13 November (uses the visitor's local time)
- Birthday-day message automatically appears on 13 November
- Ten-photo gallery with captions and navigation controls
- Romantic written love note and secret gift message
- Interactive candle-wish and cake-cutting celebration buttons
- Floating hearts, sparkles and confetti-style celebration effects
- Optional background music using the included phir-kabhi.mp3
- Responsive layout for mobile and desktop

HOW TO OPEN
1. Extract the ZIP file.
2. Open the bday_site folder.
3. Open index.html in a modern browser.
4. Tap “Open your surprise” to enter; tap the music button if you want music.

NOTES
- Keep index.html, style.css, script.js, all JPGs, and phir-kabhi.mp3 in the same folder.
- The countdown is for November 13 every year and uses local device time.
- Music playback depends on browser permissions and starts after the visitor taps the opening button.
