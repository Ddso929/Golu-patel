const photos = Array.from({ length: 10 }, (_, i) => `${i + 1}.jpg`);
const messages = [
  '😍 My wife, tum meri favourite person ho — always and forever.',
  '🥹 Tumhari smile se mera poora din roshan ho jaata hai, my love.',
  '💗 Tum cute bhi ho, meri favourite bhi — aur meri life ka sabse pyaara part bhi.',
  '🫶 Tumhare saath simple se moments bhi meri favourite memories ban jaate hain.',
  '🙈 Tum meri favourite smile, favourite hug aur favourite hello ho.',
  '💗 Tumhari care aur tumhara pyaar mere liye duniya ki sabse precious cheez hai.',
  '😂 Tumhari cute si nautanki bhi mujhe aur pyaar karna sikha deti hai.',
  '👑 My queen, my best friend, my wife — you are my favourite forever.',
  '🥰 Har din tumhe choose karne ki ek nayi wajah mil jaati hai.',
  '❤️ I love you, my wife. Aaj, kal aur har lifetime mein.'
];
const $ = id => document.getElementById(id);

// Colourful, screen-only fireworks. No real firecrackers—just a safe visual effect.
const fireworksCanvas = $('fireworksCanvas');
const fwCtx = fireworksCanvas.getContext('2d');
let fwParticles = [], fwFrame = 0, fwRunning = false, fwLastBurst = 0;
function resizeFireworks() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  fireworksCanvas.width = Math.floor(window.innerWidth * dpr);
  fireworksCanvas.height = Math.floor(window.innerHeight * dpr);
  fireworksCanvas.style.width = `${window.innerWidth}px`;
  fireworksCanvas.style.height = `${window.innerHeight}px`;
  fwCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resizeFireworks, { passive: true });
resizeFireworks();
function fireworkBurst(x = Math.random() * window.innerWidth, y = 70 + Math.random() * window.innerHeight * .42) {
  const colors = ['#ff6fae', '#ffd166', '#9bf6ff', '#cdb4ff', '#ffffff', '#ff9f1c', '#b8f2a1'];
  const hue = colors[Math.floor(Math.random() * colors.length)];
  const count = 52 + Math.floor(Math.random() * 26);
  for (let i = 0; i < count; i++) {
    const angle = Math.PI * 2 * i / count + Math.random() * .12;
    const speed = 1.1 + Math.random() * 4.2;
    fwParticles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
      life: 48 + Math.random() * 36, maxLife: 84, size: 1.2 + Math.random() * 2.2,
      color: Math.random() < .18 ? colors[Math.floor(Math.random() * colors.length)] : hue,
      sparkle: Math.random() < .3 });
  }
}
function fireworksLoop() {
  if (!fwRunning) return;
  fwCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  const now = performance.now();
  if (now - fwLastBurst > 390 && fwParticles.length < 750) {
    fireworkBurst();
    fwLastBurst = now;
  }
  fwParticles = fwParticles.filter(p => p.life > 0);
  for (const p of fwParticles) {
    p.x += p.vx; p.y += p.vy; p.vx *= .985; p.vy = p.vy * .985 + .035; p.life--;
    fwCtx.globalAlpha = Math.max(0, p.life / p.maxLife);
    fwCtx.fillStyle = p.color;
    fwCtx.beginPath(); fwCtx.arc(p.x, p.y, p.size, 0, Math.PI * 2); fwCtx.fill();
    if (p.sparkle && p.life % 5 === 0) {
      fwCtx.globalAlpha *= .65; fwCtx.fillRect(p.x - 3, p.y, 6, .8);
    }
  }
  fwCtx.globalAlpha = 1;
  fwFrame = requestAnimationFrame(fireworksLoop);
}
function launchFireworks(duration = 4200) {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  fwRunning = true;
  fwLastBurst = 0;
  fireworkBurst(window.innerWidth * (.2 + Math.random() * .6), window.innerHeight * (.18 + Math.random() * .24));
  if (!fwFrame) fireworksLoop();
  window.setTimeout(() => {
    fwRunning = false;
    cancelAnimationFrame(fwFrame); fwFrame = 0;
    fwCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    fwParticles = [];
  }, duration);
}
const cover = $('cover'), app = $('app'), bgMusic = $('bgMusic'), musicBtn = $('musicBtn');
let index = 0, heartTimer = null, countdownTimer = null;

function render() {
  const photo = $('photo');
  photo.classList.add('fade');
  window.setTimeout(() => {
    photo.src = photos[index];
    photo.alt = `A favourite memory with my wife ${index + 1}`;
    $('message').innerHTML = `${messages[index]}<span>♡ meri jaan · always special ♡</span>`;
    $('count').textContent = index + 1;
    document.querySelectorAll('.dot').forEach((dot, i) => dot.classList.toggle('active', i === index));
    photo.classList.remove('fade');
  }, 130);
}
function movePhoto(direction) { index = (index + direction + photos.length) % photos.length; render(); }
function makeDots() {
  const holder = $('photoDots');
  photos.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = `dot${i === 0 ? ' active' : ''}`;
    dot.setAttribute('aria-label', `Show photo ${i + 1}`);
    dot.addEventListener('click', () => { index = i; render(); });
    holder.appendChild(dot);
  });
}
function hearts() {
  if (document.hidden) return;
  const h = document.createElement('div');
  h.className = 'heart';
  h.textContent = ['❤️', '💗', '💖', '💕', '✨', '🌸'][Math.floor(Math.random() * 6)];
  h.style.left = `${Math.random() * 100}vw`;
  h.style.fontSize = `${15 + Math.random() * 17}px`;
  h.style.animationDuration = `${5 + Math.random() * 4}s`;
  document.body.appendChild(h);
  window.setTimeout(() => h.remove(), 9500);
}
function getNextBirthday() {
  const now = new Date();
  let target = new Date(now.getFullYear(), 10, 13, 0, 0, 0, 0);
  if (now >= new Date(now.getFullYear(), 10, 14, 0, 0, 0, 0)) target = new Date(now.getFullYear() + 1, 10, 13, 0, 0, 0, 0);
  return target;
}
let birthdayTarget = getNextBirthday();
let birthdayFireworksShown = false;
function updateCountdown() {
  const now = new Date();
  const birthdayEnd = new Date(birthdayTarget.getFullYear(), 10, 14, 0, 0, 0, 0);
  const isBirthday = now >= birthdayTarget && now < birthdayEnd;
  if (isBirthday) {
    if (!birthdayFireworksShown) { birthdayFireworksShown = true; window.setTimeout(() => launchFireworks(7000), 500); }
    $('countdownTitle').textContent = 'It’s your special day, my love!';
    $('countdownSub').textContent = 'Aaj saari khushiyan tumhare naam, meri jaan 💗';
    $('countdown').classList.add('hidden');
    document.querySelector('.date-pill').classList.add('hidden');
    $('birthdayWish').classList.remove('hidden');
    return;
  }
  if (now >= birthdayEnd) birthdayTarget = getNextBirthday();
  $('countdownTitle').textContent = 'Your day is getting closer';
  $('countdownSub').textContent = '13 November is all about celebrating you, my love 💗';
  $('countdown').classList.remove('hidden');
  document.querySelector('.date-pill').classList.remove('hidden');
  $('birthdayWish').classList.add('hidden');
  const diff = Math.max(0, birthdayTarget - now);
  const units = [ ['days', Math.floor(diff / 86400000)], ['hours', Math.floor(diff / 3600000) % 24], ['minutes', Math.floor(diff / 60000) % 60], ['seconds', Math.floor(diff / 1000) % 60] ];
  units.forEach(([id, value]) => $(id).textContent = String(value).padStart(2, '0'));
}
function celebrate() {
  launchFireworks(4800);
  for (let i = 0; i < 24; i++) {
    window.setTimeout(() => {
      const spark = document.createElement('div');
      spark.className = 'celebration';
      spark.textContent = ['💖', '✨', '🌸', '🎉', '💕'][Math.floor(Math.random() * 5)];
      spark.style.left = `${Math.random() * 100}vw`;
      spark.style.animationDuration = `${2.5 + Math.random() * 2}s`;
      document.body.appendChild(spark);
      window.setTimeout(() => spark.remove(), 5000);
    }, i * 70);
  }
}
$('startBtn').addEventListener('click', () => {
  cover.classList.add('cover-hide');
  launchFireworks(5200);
  window.setTimeout(() => { cover.remove(); app.classList.remove('hidden'); render(); }, 650);
  bgMusic.volume = 0.35;
  bgMusic.play().then(() => { musicBtn.textContent = '🔊 Music'; }).catch(() => { musicBtn.textContent = '♫ Tap for music'; });
  heartTimer = window.setInterval(hearts, 1000);
});
$('nextBtn').addEventListener('click', () => movePhoto(1));
$('prevBtn').addEventListener('click', () => movePhoto(-1));
$('nextArrowBtn').addEventListener('click', () => movePhoto(1));
musicBtn.addEventListener('click', () => {
  if (bgMusic.paused) bgMusic.play().then(() => { musicBtn.textContent = '🔊 Music'; }).catch(() => { musicBtn.textContent = '♫ Music'; });
  else { bgMusic.pause(); musicBtn.textContent = '🔇 Music'; }
});
$('giftBtn').addEventListener('click', () => {
  const opened = !$('giftMessage').classList.contains('hidden');
  $('giftMessage').classList.toggle('hidden', opened);
  $('giftBtn').setAttribute('aria-expanded', String(!opened));
  $('giftBtn').textContent = opened ? 'Tap to open your gift 💌' : 'Your little message is open 💗';
  if (!opened) { $('giftMessage').scrollIntoView({ behavior: 'smooth', block: 'center' }); celebrate(); }
});
$('celebrateBtn').addEventListener('click', celebrate);
$('fireworksBtn').addEventListener('click', () => { launchFireworks(6500); celebrate(); });

let candlesBlown = false;
$('blowCandlesBtn').addEventListener('click', () => {
  candlesBlown = true;
  $('cakeEmoji').textContent = '🍰';
  $('cakeMessage').classList.remove('hidden');
  $('cakeMessage').innerHTML = 'Wish maang li, my love? 🥹💗 Meri dua hai tumhari har subah smile se shuru ho aur har raat sukoon se khatam. Happy Birthday, my wife! May life be as gentle and beautiful with you as your heart is with everyone. ✨';
  $('blowCandlesBtn').textContent = 'Wish sent to the universe ✨';
  celebrate();
});
$('cutCakeBtn').addEventListener('click', () => {
  $('cakeEmoji').textContent = '🍰💗';
  $('cakeMessage').classList.remove('hidden');
  $('cakeMessage').innerHTML = 'Cake ka pehla piece tumhare liye, my love! 🎂❤️ Kaash main tumhare paas hota aur tumhe hug karke kehta: tum meri life ki sabse pyaari blessing ho. Aaj, kal aur har birthday par tumhari khushi celebrate karunga. 🤗💕';
  $('cutCakeBtn').textContent = 'Cake cut ho gaya! 💞';
  celebrate();
  if (!candlesBlown) {
    $('cakeMessage').insertAdjacentHTML('beforeend', '<p class="cake-note">Ab candles bhi blow kar dena aur ek wish zaroor maangna 🕯️</p>');
  }
});
makeDots();
updateCountdown();
countdownTimer = window.setInterval(updateCountdown, 1000);
render();
